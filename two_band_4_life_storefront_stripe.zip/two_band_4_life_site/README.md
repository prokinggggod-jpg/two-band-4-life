# Two Band 4 Life — Stripe-ready storefront

A responsive storefront modeled on the supplied reference image, with:
- Home / Shop / About / Contact sections
- Product cards and prices from the reference
- Working cart with quantities
- Contact email: prokinggggod@gmail.com
- Stripe Checkout integration through a server (no secret key in browser code)
- Stripe webhook endpoint for reliable paid-order confirmation
- Shipping address collection for US orders

## Run locally

1. Install Node.js.
2. In this folder run `npm install`.
3. Copy `.env.example` to `.env`.
4. An adult/authorized business owner should create and control the Stripe account and put the Stripe secret key in the server environment — never in `script.js`.
5. Set `STRIPE_SECRET_KEY` and `PUBLIC_SITE_URL`. For local testing, Stripe test keys are appropriate.
6. Run `npm start`.
7. Open `http://localhost:4242`.

## Stripe webhook

Configure a Stripe webhook pointing to:
`https://YOUR-DOMAIN/api/stripe-webhook`

Subscribe to `checkout.session.completed`, then put the webhook signing secret in `STRIPE_WEBHOOK_SECRET`.

The webhook is where you should later add fulfillment, inventory updates, order storage, and/or email notifications.

## Important

The prices are server-side and the browser cannot change them. The current catalog is:
- Life Tee — $32
- Night Hoodie — $54
- Dreams Sweatpants — $48
- Logo Cap — $28
- Reset Tee — $32

The product artwork is still placeholder CSS art. Replace it with photos of the actual products before selling them.

No Stripe credentials are included in this package. Do not send secret keys, passwords, bank information, or card information to ChatGPT.
