const path = require('path');
const express = require('express');
const Stripe = require('stripe');

const app = express();
const PORT = process.env.PORT || 4242;
const stripe = process.env.STRIPE_SECRET_KEY ? Stripe(process.env.STRIPE_SECRET_KEY) : null;

// Server-side catalog: the browser cannot change these prices.
const PRODUCTS = {
  'Life Tee': { price: 32.00 },
  'Night Hoodie': { price: 54.00 },
  'Dreams Sweatpants': { price: 48.00 },
  'Logo Cap': { price: 28.00 },
  'Reset Tee': { price: 32.00 }
};

app.use(express.static(__dirname));

app.post('/api/create-checkout-session', express.json(), async (req, res) => {
  try {
    if (!stripe) {
      return res.status(503).json({ error: 'Stripe is not configured on this server yet.' });
    }

    const cart = Array.isArray(req.body.cart) ? req.body.cart : [];
    if (!cart.length) return res.status(400).json({ error: 'Your cart is empty.' });

    // Only accept product names from the server-side catalog.
    const line_items = cart.map(item => {
      const product = PRODUCTS[item.name];
      const quantity = Number.isInteger(item.quantity) ? item.quantity : 1;
      if (!product || quantity < 1 || quantity > 20) {
        throw new Error('Invalid product or quantity.');
      }
      return {
        quantity,
        price_data: {
          currency: 'usd',
          product_data: { name: item.name },
          unit_amount: Math.round(product.price * 100)
        }
      };
    });

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items,
      billing_address_collection: 'required',
      shipping_address_collection: { allowed_countries: ['US'] },
      success_url: `${process.env.PUBLIC_SITE_URL || `http://localhost:${PORT}`}/success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.PUBLIC_SITE_URL || `http://localhost:${PORT}`}/index.html?checkout=cancelled`,
      automatic_tax: { enabled: false }
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: err.message || 'Could not start checkout.' });
  }
});

// Stripe requires the raw request body for webhook signature verification.
app.post('/api/stripe-webhook', express.raw({ type: 'application/json' }), (req, res) => {
  if (!stripe || !process.env.STRIPE_WEBHOOK_SECRET) {
    return res.status(503).send('Stripe webhook is not configured.');
  }

  let event;
  try {
    const signature = req.headers['stripe-signature'];
    event = stripe.webhooks.constructEvent(req.body, signature, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    console.log('PAID ORDER:', session.id, session.customer_details?.email || 'no email');
    // TODO: add your order-fulfillment/email/database logic here.
  }

  res.json({ received: true });
});

app.listen(PORT, () => {
  console.log(`Two Band 4 Life running at http://localhost:${PORT}`);
});
